        let add_room_form = document.getElementById('add_room_form');

        add_room_form.addEventListener('submit', function(e) {
            e.preventDefault();
            add_rooms();
        });

        function add_rooms() {
            let data = new FormData();
            data.append('add_room', '');
            data.append('name', add_room_form.elements['name'].value);
            data.append('area', add_room_form.elements['area'].value);
            data.append('price', add_room_form.elements['price'].value);
            data.append('quantity', add_room_form.elements['quantity'].value);
            data.append('sharing', add_room_form.elements['sharing'].value);
            data.append('rating', add_room_form.elements['rating'].value);
            data.append('location', add_room_form.elements['location'].value);
            data.append('d_location', add_room_form.elements['d-location'].value);
            data.append('desc', add_room_form.elements['desc'].value);

            let room_category = [];
            add_room_form.elements['category'].forEach(el => {
                if (el.checked) {
                    // console.log(el.value);
                    room_category.push(el.value);
                }
            });
            let features = [];
            add_room_form.elements['features'].forEach(el => {
                if (el.checked) {
                    // console.log(el.value);
                    features.push(el.value);
                }
            });
            

            let facilities = [];
            add_room_form.elements['facilities1'].forEach(el => {
                if (el.checked) {
                    // console.log(el.value);
                    facilities.push(el.value);
                }
            });

            let pg_patnar = [];
            add_room_form.elements['pg-patnar'].forEach(el => {
                if (el.checked) {
                    // console.log(el.value);
                    pg_patnar.push(el.value);
                }
            });


            data.append('category', JSON.stringify(room_category));
            data.append('features', JSON.stringify(features));
            data.append('facilities', JSON.stringify(facilities));
            data.append('pg-patnar', JSON.stringify(pg_patnar));




            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/rooms.php", true);


            xhr.onload = function() {
                var myModal = document.getElementById('add-room');
                var modal = bootstrap.Modal.getInstance(myModal);
                modal.hide();

                if (this.responseText == 1) {
                    alert('success', 'New Room Added Successfully!');
                    add_room_form.reset();
                    get_all_rooms();
                } else {
                    alert('error', 'Server Down!');
                }
            }


            xhr.send(data);
        }

        function get_all_rooms() {
            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/rooms.php", true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');


            xhr.onload = function() {
                document.getElementById('room-data').innerHTML = this.responseText;
            }


            xhr.send('get_all_rooms');
        }



        let edit_room_form = document.getElementById('edit_room_form');

        function edit_details(id) {
            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/rooms.php", true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');


            xhr.onload = function() {
                let data = JSON.parse(this.responseText);
                edit_room_form.elements['name'].value = data.roomdata.name;
                edit_room_form.elements['area'].value = data.roomdata.area;
                edit_room_form.elements['price'].value = data.roomdata.price;
                edit_room_form.elements['quantity'].value = data.roomdata.quantity;
                edit_room_form.elements['sharing'].value = data.roomdata.sharing;
                edit_room_form.elements['rating'].value = data.roomdata.rating;
                edit_room_form.elements['location'].value = data.roomdata.location;
                edit_room_form.elements['d-location'].value = data.roomdata.d_location;
                edit_room_form.elements['desc'].value = data.roomdata.description;
                edit_room_form.elements['room_id'].value = data.roomdata.id;

                
                edit_room_form.elements['features'].forEach(el => {
                    if (data.features.includes(Number(el.value))) {
                        el.checked = true;
                    }
                });

                edit_room_form.elements['facilities'].forEach(el => {
                    if (data.facilities.includes(Number(el.value))) {
                        el.checked = true;
                    }
                });

                edit_room_form.elements['pg-patnar'].forEach(el => {
                    if (data.room_patnar.includes(Number(el.value))) {
                        el.checked = true;
                    }
                });
                edit_room_form.elements['category'].forEach(el => {
                    if (data.category.includes(Number(el.value))) {
                        el.checked = true;
                    }
                });
            }


            xhr.send('get_room=' + id);
        }

        edit_room_form.addEventListener('submit', function(e) {
            e.preventDefault();
            submit_edit_rooms();
        });


        function submit_edit_rooms() {
            let data = new FormData();
            data.append('edit_room', '');
            data.append('room_id', edit_room_form.elements['room_id'].value);
            data.append('name', edit_room_form.elements['name'].value);
            data.append('area', edit_room_form.elements['area'].value);
            data.append('price', edit_room_form.elements['price'].value);
            data.append('quantity', edit_room_form.elements['quantity'].value);
            data.append('sharing', edit_room_form.elements['sharing'].value);
            data.append('rating', edit_room_form.elements['rating'].value);
            data.append('location', edit_room_form.elements['location'].value);
            data.append('d_location', edit_room_form.elements['d-location'].value);
            data.append('desc', edit_room_form.elements['desc'].value);

            let category = [];
            edit_room_form.elements['category'].forEach(el => {
                if (el.checked) {
                    category.push(el.value);
                }
            });
            let features = [];
            edit_room_form.elements['features'].forEach(el => {
                if (el.checked) {
                    features.push(el.value);
                }
            });

            let facilities = [];
            edit_room_form.elements['facilities'].forEach(el => {
                if (el.checked) {
                    facilities.push(el.value);
                }
            });

            let pg_patnar = [];
            edit_room_form.elements['pg-patnar'].forEach(el => {
                if (el.checked) {
                    pg_patnar.push(el.value);
                }
            });


            data.append('category', JSON.stringify(category));
            data.append('features', JSON.stringify(features));
            data.append('facilities', JSON.stringify(facilities));
            data.append('pg-patnar', JSON.stringify(pg_patnar));

            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/rooms.php", true);


            xhr.onload = function() {
                var myModal = document.getElementById('edit-room');
                var modal = bootstrap.Modal.getInstance(myModal);
                modal.hide();

                if (this.responseText == 1) {
                    alert('success', 'Room Data Edited Successfully!');
                    edit_room_form.reset();
                    get_all_rooms();
                } else {
                    alert('error', 'Server Down!');
                }
            }


            xhr.send(data);
        }


        function toggle_status(id, val) {
            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/rooms.php", true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');


            xhr.onload = function() {
                if (this.responseText == 1) {
                    alert('success', 'Status toggled!');
                    get_all_rooms();
                } else {
                    alert('error', 'Server down!');

                }
            }


            xhr.send('toggle_status=' + id + '&value=' + val);
        }


        let add_image_form = document.getElementById('add_image_form');
        add_image_form.addEventListener('submit', function(e) {
            e.preventDefault();
            add_image();
        })

        function add_image() {
            let data = new FormData();
            data.append('image', add_image_form.elements['image'].files[0]);
            data.append('room_id', add_image_form.elements['room_id'].value);
            data.append('add_image', '');

            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/rooms.php", true);


            xhr.onload = function() {
               
                if (this.responseText == 'inv_img') {
                    alert('error', 'Only JPG, PNG and Webp images are allowed!','image-alert');
                } else if (this.responseText == 'inv_size') {
                    alert('error', 'Image size should be less than 1 mb','image-alert');
                } else if (this.responseText == 'upd_failed') {
                    alert('error', 'Somthing wents wrong','image-alert');
                } else {
                    alert('success', 'New image added Successfully','image-alert');
                    room_images(add_image_form.elements['room_id'].value,document.querySelector("#room-images .modal-title").innerText);
                    add_image_form.reset();
                }
            }

            xhr.send(data);
        }

        function room_images(id,rname){
            document.querySelector("#room-images .modal-title").innerText = rname;
            add_image_form.elements['room_id'].value = id;
            add_image_form.elements['image'].value = '';

            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/rooms.php", true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');


            xhr.onload = function() {
              document.getElementById('room-image-data').innerHTML = this.responseText;
            }


            xhr.send('get_room_images='+id);

        }


        function rem_image(img_id,room_id){
            let data = new FormData();
            data.append('image_id',img_id);
            data.append('room_id',room_id);
            data.append('rem_image', '');

            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/rooms.php", true);


            xhr.onload = function() {
               
                if (this.responseText == 1) {
                    alert('success', 'Image Removed','image-alert');
                    room_images(room_id,document.querySelector("#room-images .modal-title").innerText);
                } 
                else {
                    alert('error', 'Server Down!','image-alert');
                }
            }

            xhr.send(data);
        }

        function thumb_image(img_id,room_id){
            let data = new FormData();
            data.append('image_id',img_id);
            data.append('room_id',room_id);
            data.append('thumb_image', '');

            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/rooms.php", true);


            xhr.onload = function() {
               
                if (this.responseText == 1) {
                    alert('success', 'Image Thumbnail Changed','image-alert');
                    room_images(room_id,document.querySelector("#room-images .modal-title").innerText);
                } 
                else {
                    alert('error', 'Server Down!','image-alert');
                }
            }

            xhr.send(data);
        }

        function remove_room(room_id){
            if(confirm("Are you sure, You want to delete this room")){

                let data = new FormData();
                data.append('room_id',room_id);
                data.append('remove_room', '');
    
                let xhr = new XMLHttpRequest();
                xhr.open("POST", "ajax/rooms.php", true);
    
    
                xhr.onload = function() {
                   
                    if (this.responseText == 1) {
                        alert('success', 'Room Removed');
                        get_all_rooms();
                    } 
                    else {
                        alert('error', 'Server Down!');
                    }
                }
    
                xhr.send(data);
            }
        }



        window.onload = function() {
            get_all_rooms();
        }