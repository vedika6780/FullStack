<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Merienda:wght@400;700&family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">


    <?php 
    session_start();
    require ('./Admin/inc/db_config.php');
    require ('./Admin/inc/essentials.php');

    $setting_q = "SELECT * FROM `settings` WHERE `sr_no`=?";
    $values = [1];
    $setting_r = mysqli_fetch_assoc(select($setting_q,$values,'i'));
    if($setting_r['shutdown']){
       echo<<<alertbar
           <div class="bg-danger text-center p-2 fw-bold">
                <i class="bi bi-exclamation-triangle-fill me-1"></i>
                Bookings are temporarily closed!
           </div>
   
       alertbar;
    }

    $contact_q = "SELECT * FROM `contact_details` WHERE `sr_no`=?";
    $contact_r = mysqli_fetch_assoc(select($contact_q,$values,'i'));
    
    ?>