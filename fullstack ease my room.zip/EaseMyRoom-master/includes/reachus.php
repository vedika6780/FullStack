
<h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-fonts">
        REACH US
    </h2>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 p-4 mb-lg-0 mb-3 bg-white rounded">
                <iframe class="w-100 rounded" height="320px" src="<?php echo $contact_r['iframe'] ?>" loading="lazy"></iframe>
            </div>
            <div class="col-lg-4 col-md-4">
                <div class="bg-white p-4 rounded mb-4">
                    <h5>
                        Call us
                    </h5>
                    <a href="tel: +<?php echo $contact_r['pn1'] ?>" class="d-inline-block mb-2 text-decoration-none text-dark"><i class="bi bi-telephone-fill"></i> +<?php echo $contact_r['pn1'] ?></a>
                    <br>
                    <a href="tel: +<?php echo $contact_r['pn2'] ?>" class="d-inline-block mb-2 text-decoration-none text-dark"><i class="bi bi-telephone-fill"></i> +<?php echo $contact_r['pn2'] ?></a>
                </div>
                <div class="bg-white p-4 rounded mb-4">
                    <h5>
                        Follow us
                    </h5>
                    <a href="<?php echo $contact_r['insta'] ?>" class="d-inline-block mb-3">
                        <span class="badge bg-light text-dark fs-6 p-2"><i class="bi bi-instagram me-1"></i>Instagram
                        </span>
                    </a>
                    
                    <a href="<?php echo $contact_r['fb'] ?>" class="d-inline-block mb-3">
                        <span class="badge bg-light text-dark fs-6 p-2"><i class="bi bi-facebook me-1"></i>Facebook
                        </span>
                    </a>
                    <a href="<?php echo $contact_r['tw'] ?>" class="d-inline-block mb-3">
                        <span class="badge bg-light text-dark fs-6 p-2"><i class="bi bi-twitter me-1"></i>Twitter
                        </span>
                    </a>
                  
                    <a href="<?php echo $contact_r['wa'] ?>" class="d-inline-block">
                        <span class="badge bg-light text-dark fs-6 p-2"><i class="bi bi-whatsapp me-1"></i>WhatsApp
                        </span>
                    </a>
                </div>
            </div>
        </div>
    </div>