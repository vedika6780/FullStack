<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ease My Room - FACILITIES</title>
    <?php require("./includes/links.php"); ?>
</head>
</head>

<body class="bg-light">

    <!-- nav-bar -->
    <?php include("./includes/header.php"); ?>
    <!-- nav-bar-end  -->

    <div class="my-5 px-4">
        <h2 class="fw-bold h-fonts text-center">OUR FACILITIES</h2>
        <div class="h-line bg-dark"></div>
        <p class="text-center mt-3">Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo, excepturi <br> neque! Nisi voluptatum dicta veniam fugit deserunt exercitationem nesciunt laboriosam?</p>
    </div>

    <div class="container">
        <div class="row">
            <?php
            $res = selectAll('facilities');
            $path = FEATURES_IMG_PATH;
            while($row = mysqli_fetch_assoc($res)){
                echo<<<data
                    <div class="col-lg-4 col-md-6 mb-5 px-4">
                        <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
                            <div class="d-flex align-items-center mb-2">
                                <img src="$path$row[icon]" alt="" width="40px">
                                <h5 class="m-0 ms-3">$row[name]</h5>
                            </div>
                            <p>$row[description]</p>
                        </div>
                    </div>

                data;
            }

            ?>
        </div>
    </div>


    <!--Footer-->
    <?php include("./includes/footer.php"); ?>
    <!--Footer end-->


</body>

</html>