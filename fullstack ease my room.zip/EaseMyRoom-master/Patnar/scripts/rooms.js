
        function get_all_rooms() {
            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/rooms.php", true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');


            xhr.onload = function() {
                document.getElementById('room-data').innerHTML = this.responseText;
            }


            xhr.send('get_all_rooms');
        }



        let edit_room_form = document.getElementById('edit_room_form');

        function edit_details(id) {
            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/rooms.php", true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');


            xhr.onload = function() {
                let data = JSON.parse(this.responseText);
                edit_room_form.elements['quantity'].value = data.roomdata.quantity;
                edit_room_form.elements['room_id'].value = data.roomdata.id;
            }


            xhr.send('get_room=' + id);
        }

        edit_room_form.addEventListener('submit', function(e) {
            e.preventDefault();
            submit_edit_rooms();
        });


        function submit_edit_rooms() {
            let data = new FormData();
            data.append('edit_room', '');
            data.append('room_id', edit_room_form.elements['room_id'].value);
            data.append('quantity', edit_room_form.elements['quantity'].value);

            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/rooms.php", true);


            xhr.onload = function() {
                var myModal = document.getElementById('edit-room');
                var modal = bootstrap.Modal.getInstance(myModal);
                modal.hide();

                if (this.responseText == 1) {
                    alert('success', 'Room Data Edited Successfully!');
                    edit_room_form.reset();
                    get_all_rooms();
                } else {
                    alert('error', 'Server Down!');
                }
            }


            xhr.send(data);
        }


     



        window.onload = function() {
            get_all_rooms();
        }