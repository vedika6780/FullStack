<?php
require('./inc/essentials.php');
require('./inc/db_config.php');
session_start();
    if((isset($_SESSION['patnarLogin']) && $_SESSION['patnarLogin']==true)){
        redirect('./dashboard.php');
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin- Login Panel</title>
    <?php require("./inc/links.php"); ?>
    <style>
        div.login-form {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 400px;
        }
    </style>
</head>

<body class="bg-light">
    <div class="login-form text-center rounded bg-white shadow overflow-hidden">
        <form method="POST">
            <h4 class="bg-dark text-white py-3">PATNAR LOGIN PANEL</h4>
            <div class="p-4">
                <div class="mb-3">
                    <input name="username" required type="text" class="form-control shadow-none text-center" placeholder="Username">
                </div>
                <div class="mb-4">
                    <input name="pass" required type="password" class="form-control text-center shadow-none" placeholder="Password">
                </div>

                <button name="login" type="submit" class="btn text-white custom-bg shadow-none">LOGIN</button>

            </div>
        </form>
    </div>

    <?php
    if (isset($_POST['login'])) {
        $frm_data = filteration($_POST);

        $query = "SELECT * FROM `pg_patnar` WHERE `name`=? AND `password`=?";
        $values = [$frm_data['username'], $frm_data['pass']];
        $res = select($query, $values, "ss");
        if ($res->num_rows == 1) {
            
            $row = mysqli_fetch_assoc($res);
            $_SESSION['patnarLogin'] = true;
            $_SESSION['patnarId'] = $row['id'];
            redirect('./dashboard.php');

        } else {
           alert('error','Login failed - Invalid Credentials!');
        }
    }

    ?>

    <?php require("./inc/scripts.php"); ?>
</body>

</html>