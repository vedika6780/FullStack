<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ease My Room - About</title>
    <?php require("./includes/links.php"); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    <!-- <style>
        .box:hover{
            border-top-color: var(--teal)!important;
        }
    </style> -->

</head>

<body class="bg-light">

    <!-- nav-bar -->
    <?php include("./includes/header.php"); ?>
    <!-- nav-bar-end  -->

    <div class="my-5 px-4">
        <h2 class="fw-bold h-fonts text-center">ABOUT US</h2>
        <div class="h-line bg-dark"></div>
        <p class="text-center mt-3">Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo, excepturi <br> neque! Nisi voluptatum dicta veniam fugit deserunt exercitationem nesciunt laboriosam?</p>
    </div>

    <div class="container">
        <div class="row justify-content-between align-items-center">
            <div class="col-lg-6 col-md-5 mb-4 order-lg-1 order-md-1 order-2">
                <h3 class="mb-3">Lorem ipsum dolor sit.</h3>

                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Doloribus aliquid cumque eaque, ullam possimus inventore. Quasi.Lorem ipsum dolor sit, amet consectetur adipisicing elit. Doloribus aliquid cumque eaque, ullam possimus inventore. Quasi.</p>
            </div>
            <div class="col-lg-5 col-md-5 mb-4 order-lg-2 order-md-1 order-1">
                <img src="./images/about/sarthak.gulati.jpg" alt="" class="w-100">
            </div>

        </div>
    </div>

    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-3 col-md-6 mb-4 px-4">
                <div class="bg-white rounded shadow p-4 border-top border-4 text-center pop">
                    <img src="./images/about/hotel.svg" alt="" width="70px">
                    <h4 class="mt-3">100+ ROOMS</h4>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4 px-4">
                <div class="bg-white rounded shadow p-4 border-top border-4 text-center pop">
                    <img src="./images/about/customers.svg" alt="" width="70px">
                    <h4 class="mt-3">200+ CUSTOMERS</h4>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4 px-4">
                <div class="bg-white rounded shadow p-4 border-top border-4 text-center pop">
                    <img src="./images/about/rating.svg" alt="" width="70px">
                    <h4 class="mt-3">150+ REVIEWS</h4>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4 px-4">
                <div class="bg-white rounded shadow p-4 border-top border-4 text-center pop">
                    <img src="./images/about/staff.svg" alt="" width="70px">
                    <h4 class="mt-3">100+ STAFFS</h4>
                </div>
            </div>
        </div>
    </div>

    <h3 class="my-5 fw-bold h-fonts text-center">
        MANAGEMENT TEAM
    </h3>
    <div class="container px-4">
        <div class="swiper mySwiper">
            <div class="swiper-wrapper mb-5">

                <?php
                $path = ABOUT_IMG_PATH;
                $about_r = selectAll('team_details');
                while($row = mysqli_fetch_assoc($about_r)){
                    echo <<<data
                        <div class="swiper-slide bg-white text-center overflow-hidden rounded">
                            <img src="$path$row[picture]" class="w-100">
                            <h5 class="mt-2">$row[name]</h5>
                        </div>

                    data;
                }
                
                ?>
            </div>
            <div class="swiper-pagination"></div>
        </div>
    </div>

    <!--Footer-->
    <?php include("./includes/footer.php"); ?>
    <!--Footer end-->


    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <script>
        var swiper = new Swiper(".mySwiper", {
            spaceBetween: 40,
            pagination: {
                el: ".swiper-pagination",
            },
            autoplay: {
                delay: 3500,
                disableOnInteraction: false,
            },
            breakpoints: {
                320: {
                    slidesPerView: 1,
                },
                640: {
                    slidesPerView: 1,
                },
                768: {
                    slidesPerView: 3,
                },
                1024: {
                    slidesPerView: 3,
                },

            },
        });
    </script>
</body>

</html>